package com.example.calulator

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.calulator.ui.theme.CalulatorTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            CalulatorTheme {
                CalculatorScreen()
            }
        }
    }
}

@Composable
fun CalculatorScreen() {
    var displayValue by remember { mutableStateOf("0") }
    var operand1 by remember { mutableStateOf<Double?>(null) }
    var activeOperator by remember { mutableStateOf<String?>(null) }
    var shouldResetDisplay by remember { mutableStateOf(false) }

    val onNumberClick: (String) -> Unit = { number ->
        if (displayValue == "0" || shouldResetDisplay) {
            displayValue = number
            shouldResetDisplay = false
        } else {
            displayValue += number
        }
    }

    val onOperatorClick: (String) -> Unit = { op ->
        operand1 = displayValue.toDoubleOrNull()
        activeOperator = op
        shouldResetDisplay = true
    }

    val onEqualsClick = {
        val operand2 = displayValue.toDoubleOrNull()
        if (operand1 != null && activeOperator != null && operand2 != null) {
            val result = when (activeOperator) {
                "+" -> operand1!! + operand2
                "-" -> operand1!! - operand2
                "×" -> operand1!! * operand2
                "÷" -> if (operand2 != 0.0) operand1!! / operand2 else Double.NaN
                else -> operand2
            }
            displayValue = if (result.isNaN()) "Error" else {
                if (result % 1.0 == 0.0) result.toLong().toString() else result.toString()
            }
            operand1 = null
            activeOperator = null
            shouldResetDisplay = true
        }
    }

    val onClear = {
        displayValue = "0"
        operand1 = null
        activeOperator = null
        shouldResetDisplay = false
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF17171C))
            .padding(24.dp),
        verticalArrangement = Arrangement.Bottom
    ) {
        Text(
            text = displayValue,
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 48.dp),
            fontSize = 80.sp,
            color = Color.White,
            textAlign = TextAlign.End,
            maxLines = 1,
            fontWeight = FontWeight.Light
        )

        val buttons = listOf(
            listOf("C", "±", "%", "÷"),
            listOf("7", "8", "9", "×"),
            listOf("4", "5", "6", "-"),
            listOf("1", "2", "3", "+"),
            listOf("0", ".", "=")
        )

        buttons.forEach { row ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                row.forEach { label ->
                    val weight = if (label == "0") 2f else 1f
                    CalcButton(
                        text = label,
                        modifier = Modifier
                            .weight(weight)
                            .aspectRatio(if (label == "0") 2.1f else 1f),
                        onClick = {
                            when (label) {
                                in "0".."9" -> onNumberClick(label)
                                "." -> if (!displayValue.contains(".")) displayValue += "."
                                "C" -> onClear()
                                "±" -> {
                                    val v = displayValue.toDoubleOrNull() ?: 0.0
                                    displayValue = if ((v * -1) % 1.0 == 0.0) (v * -1).toLong().toString() else (v * -1).toString()
                                }
                                "%" -> {
                                    val v = displayValue.toDoubleOrNull() ?: 0.0
                                    displayValue = (v / 100.0).toString()
                                }
                                "÷", "×", "-", "+" -> onOperatorClick(label)
                                "=" -> onEqualsClick()
                            }
                        }
                    )
                }
            }
        }
    }
}

@Composable
fun CalcButton(
    text: String,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    val bgColor = when (text) {
        "C", "±", "%" -> Color(0xFF4E505F)
        "÷", "×", "-", "+", "=" -> Color(0xFF4B5EFC)
        else -> Color(0xFF2E2F3E)
    }

    Box(
        modifier = modifier
            .clip(CircleShape)
            .background(bgColor)
            .clickable { onClick() },
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = text,
            color = Color.White,
            fontSize = 30.sp,
            fontWeight = FontWeight.Medium
        )
    }
}
